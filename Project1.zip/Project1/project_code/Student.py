class Student:
    def __init__(self, height, weight, gender=0):
        self.height = height
        self.weight = weight
        self.gender = gender

    